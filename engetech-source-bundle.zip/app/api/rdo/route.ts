import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { withAuth } from "@/lib/authMiddleware";

export async function GET(request: NextRequest) {
  return withAuth(request, async (req, tenantId) => {
    try {
      const obraId = req.nextUrl.searchParams.get("obraId");
      const rdos = await prisma.rDO.findMany({
        where: { tenantId, ...(obraId ? { obraId } : {}) },
        include: {
          obra: { include: { cliente: true } },
          equipe: true,
          atividades: true,
          fotos: true,
        },
        orderBy: { data: "desc" },
      });
      return NextResponse.json(rdos);
    } catch {
      return NextResponse.json({ error: "Erro interno" }, { status: 500 });
    }
  });
}

export async function POST(request: NextRequest) {
  return withAuth(request, async (req, tenantId) => {
    try {
      const body = await req.json();
      const rdo = await prisma.rDO.create({
        data: {
          tenantId,
          obraId: body.obraId,
          data: body.data ? new Date(body.data) : new Date(),
          clima: body.clima || "ensolarado",
          tempMax: body.tempMax ? Number(body.tempMax) : null,
          tempMin: body.tempMin ? Number(body.tempMin) : null,
          anotacoes: body.anotacoes || null,
          ocorrencias: body.ocorrencias || null,
          equipe: {
            create: (body.equipe || []).map(
              (e: {
                nome: string;
                funcao: string;
                presente?: boolean;
                horas?: number;
              }) => ({
                nome: e.nome,
                funcao: e.funcao,
                presente: e.presente ?? true,
                horas: Number(e.horas || 8),
              }),
            ),
          },
          atividades: {
            create: (body.atividades || []).map(
              (a: {
                descricao: string;
                etapa?: string;
                percentual?: number;
                status?: string;
              }) => ({
                descricao: a.descricao,
                etapa: a.etapa || null,
                percentual: Number(a.percentual || 0),
                status: a.status || "executado",
              }),
            ),
          },
        },
        include: {
          obra: { include: { cliente: true } },
          equipe: true,
          atividades: true,
          fotos: true,
        },
      });
      return NextResponse.json(rdo, { status: 201 });
    } catch (error) {
      console.error("Erro ao criar RDO:", error);
      return NextResponse.json({ error: "Erro interno" }, { status: 500 });
    }
  });
}
